/**
 * 
 */

$(document).ready(function() {
	loadMain();
});

function loadMain() {
	$("#Main").load("Main.html", function() {
		$("#BTInscription").click(function() {
			loadInscription();
		});
		$("#BTList").click(function() {
			loadList();
		});
	});
}




function loadInscription() {
	$("#ShowMessage").empty();
	$("#Main").load("AddInscription.html", function() {
		$("#BTVInscription").click(function() {
			client = {};
			client.nom=$("#nom").val();
			client.prenom=$("#prenom").val();		
			
			
			compte = {};
			compte.username=$("#username").val();
			compte.password=$("#password").val();		
			
			
			ass = {};
			ass.clientId= invokeGet("rest/idClient", client,"failed to id client", function(response) {
				ass.clientId= response;});				
			ass.compteId=invokeGet("rest/idCompte",compte, "failed to id compte", function(response) {
				ass.compteId= response;});
			
			
			invokePost("rest/addClient", client, "client was added", "failed to add a client");
			invokePost("rest/addCompte", compte, "compte was added", "failed to add a compte");
			invokePost("rest/associate", ass, "association was created", "failed to create association");
		
		});
		$("#BTVMain").click(function() {
			loadMain();
		});
	});
}



function loadList() {
	$("#ShowMessage").empty();
	listClients = invokeGet("rest/listClients", "failed to list clients", function(response) {
		var list;
		listClients = response;
		if (listClients== null) return;
		list="<ul>";
		for (var i=0; i < listClients.length; i++) {
			var client = listClients[i];					
			list+="<li>"+client.nom+" "+client.prenom+"</li>";
			list+="<ul>";
			for (var j=0; j < client.compte.length; j++) {
				var compte = client.compte[j];
				list+="<li>"+compte.username+" "+compte.password+"</li>";
			}
			list+="</ul><br>";
		}
		list+="</ul><br>";
		$("#Main").empty();
		$("#Main").append(list);
	});
}

function invokePost(url, data, successMsg, failureMsg) {
	jQuery.ajax({
	    url: url,
	    type: "POST",
	    data: JSON.stringify(data),
	    dataType: "json",
	    contentType: "application/json; charset=utf-8",
	    success: function (response) {
	    	$("#ShowMessage").text(successMsg);
	    },
	    error: function (response) {
	    	$("#ShowMessage").text(failureMsg);
	    }
	});
}
function invokeGet(url, failureMsg, responseHandler) {
	jQuery.ajax({
	    url: url,
	    type: "GET",
	    success: responseHandler,
	    error: function (response) {
	    	$("#ShowMessage").text(failureMsg);
	    }
	});
}