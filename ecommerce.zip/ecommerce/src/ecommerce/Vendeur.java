package ecommerce;

public class Vendeur {

}
