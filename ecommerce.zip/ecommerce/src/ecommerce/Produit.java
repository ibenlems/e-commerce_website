package ecommerce;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class Produit {

	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	int id;
	Acheteur acheteur;
	Vendeur vendeur;
	
}
