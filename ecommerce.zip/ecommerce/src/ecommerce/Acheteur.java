package ecommerce;

public class Acheteur {

}
