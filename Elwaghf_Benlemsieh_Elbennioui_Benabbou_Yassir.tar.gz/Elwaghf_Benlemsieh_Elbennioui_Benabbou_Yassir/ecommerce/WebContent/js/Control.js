/**
 * 
 */

$(document).ready(function() {
	loadMain();
});

function loadMain() {
	$("#Main").load("Main.html", function() {
		var list, list1;
		invokeGet("rest/listLivreurs", "failed to list livreurs", function(response) {
			list = response;
			if (list.length === 0) {
		livreur = {};
		livreur.nom="Livraison gratuite";
		invokePost("rest/addLivreur", livreur, "livreur was added", "failed to add a livreur");
			}
			
		});
		invokeGet("rest/listCategories", "failed to list Categories", function(response) {
            list1 = response;
            if (list1.length === 0) {
                   categorie={};
                      categorie.name="Vetements"
                      invokePost("rest/addCategorie", categorie, "Categorie was  added", "failed to add a categorie");
                      categorie2={};
                     categorie2.name="Electromenager"
                     invokePost("rest/addCategorie", categorie2, "Categorie was added", "failed to add a categorie");
                     categorie3={};
                     categorie3.name="Bijoux"
                     invokePost("rest/addCategorie", categorie3, "Categorie was added", "failed to add a categorie");
            }

        });
		
		$("#BTInscription").click(function() {
				loadAddClient();
						
		});
		
		$("#BTIdentification").click(function() {
			loadIdentification();
					
		});
		
		$("#BTAjoutProduit").click(function() {
			loadAjoutProduit();
		});
		
		$("#BTList").click(function() {
			loadList();
		});
	});
}

function loadAddClient(){
	$("#ShowMessage").empty();
	$("#Main").load("AddClient.html", function() {		
		
		$("#BTVSuivant").click(function() {
			client = {};
			client.nom=$("#nom").val();
			client.prenom=$("#prenom").val();				
			invokePost("rest/addClient", client, "client was added", "failed to add a client");			
			loadAddCompte();
			
			
		});

	});
}


function loadAddCompte() {

	$("#Main").load("AddCompte.html", function() {
		
		var $champ = $('.champ');	
	
		// le code précédent se trouve ici
	
		$champ.keyup(function(){
			
		    if($(this).val().length < 8){ // si la chaîne de caractères est inférieure à 5
		        $(this).css({ // on rend le champ rouge
		            borderColor : 'red',
			    color : 'red'
		        });
		     }
		     else{
		         $(this).css({ // si tout est bon, on le rend vert
			     borderColor : 'green',
			     color : 'green'
			 });
		     }
		});
	
	
		$("#BTVValider").click(function() {				

			    compte = {};
				compte.username=$("#username").val();
				compte.password=$("#password").val();
						
				
				invokePost("rest/addCompte", compte, "compte was added", "failed to add a compte");
				
				var listClients, listComptes;
				invokeGet("rest/listClients", "failed to list comptes", function(response) {
					listClients = response;
					if (listClients == null) return;
					listComptes = invokeGet("rest/listComptes", "failed to list clients", function(response) {
						listComptes = response;
						if (listComptes == null) return;
						var person = listClients[listClients.length - 1];
						var comptep = listComptes[listComptes.length - 1];
						ass = {};
						ass.clientId = person.id;
						ass.compteId = comptep.id;
						invokePost("rest/associate", ass, "association was created", "failed to create association");
						loadMain();
					});
				});	
			
			
		});
		
	});
}

function loadList(){
    $("#ShowMessage").empty();
    $("#Main").load("ListProduits.html", function() {

        for (var i=0;i<4;i++){
        $("#ListOfProducts").append( "<div class=p-flex><div class=p-flex-in> \n " +
                "  <img  class=p-img src=images/shopping.png />" +
                "  <div class=p-name>nom du prdouit</div> \n" +
                "  <div class=p-price>€prix</div> \n" +
                "  <div class=p-desc>description</div> \n " +
                "  <button class=p-add>Acheter</button> \n" +
                "</div></div>");
        }
        var listProduits;
        invokeGet("rest/listProduits", "failed to list products", function(response) {

            listProduits = response;
            if (listProduits == null) return;
            var len = listProduits.length;
            alert(len);
            for (var i=0; i < listProduits.length; i++) {
                var produit = listProduits[i];
                $("#ListOfProducts").append( "<div class=p-flex><div class=p-flex-in> \n " +
                        "  <img class=p-img src="+produit.url+" />" +
                        "  <div class=p-name>"+produit.nom+"</div> \n" +
                        "  <div class=p-price>€"+produit.prix+"</div> \n" +
                        "  <div class=p-name>"+produit.category+"</div> \n " +
                        "  <div class=p-desc>"+produit.description+"</div> \n " +
                        "  <button class=p-add>Acheter</button> \n" +
                        "</div></div>");
            }
            

        });




    });

}

function history(client) {
	
	listClients = invokeGet("rest/listClients", "failed to list clients", function(response) {
		listClients = response;
		if (listClients == null) return;
		for (var i=0; i < listClients.length; i++) {
		var person = listClients[i];
		var list ="";
		var prixtotal=parseInt("0");
		
		list += "<head>" +
	     " <style>"+
	     "    table, th, td {"+
	            "border: 1px solid black; "+
	   "      }"+
	   "   </style>"+
	   "</head>"+
	   "<body>"+
	     " <h1>Panier </h1>"+
	     " <table>"+
	     "    <tr>"+
	     "       <th>Produits</th>"+
	     "       <th>Prix</th>"+
	     "    </tr>";
		if (person.username == client.username && person.password==client.password) {
			for (var j=0; j < person.produits.length; j++) {
				var produit = person.produits[j];
				   
				     list+=
				     "    <tr>" +
				     "       <td>"+produit.nom+"</td>"+
				     "       <td>"+produit.prix+"</td>"+
				     "    </tr>";
				prixtotal+=parseInt(produit.prix);
			}
			list+="  </table>";
			list +="prix total = " + prixtotal + "<br>" ;
			list += "<input type=button onclick=livraison() value=Confirmer > <br>" +
			   "</body>";
			$("#Main").empty();
			$("#Main").append(list);
			as = {};
			as.livreurId = 1;
			as.produitId = produit.id;
			invokePost("rest/livrer", as, "association was created", "failed to create association");
	
		}

		
		}
	});
	
}


function livraison(){
	var list="";
	list += "<h1>Choisir le livreur </h1>" +
    "<select id =Livreur name=Livreur>" +
    "<option value=1></option>"+
    "<option value=2>Livraison gratuite</option>"+
    "</select>";
	list += "<input type=button onclick=valider() value=Valider > <br>" ;
	$("#Main").empty();
	$("#Main").append(list);


}

function valider(){
	alert("votre commande a été validé");
	loadMain();
	
}

function loadListcl(client){
	$("#ShowMessage").empty();
	$("#Main").load("ListProduits.html", function() {
		/*invokeGet("rest/listProduits", "failed to list products", function(response) {			
		});*/
		
		for (var i=0;i<4;i++){
		$("#ListOfProducts").append( "<div class=p-flex><div class=p-flex-in> \n " +
				"  <img  class=p-img src=images/shopping.png />" +
				"  <div class=p-name>nom du prdouit</div> \n" +
				"  <div class=p-price>€prix</div> \n" +
				"  <div class=p-desc>description</div> \n " +
				"  <button class=p-add>Acheter</button> \n" +
				"</div></div>");
		}
		var listProduits;
		invokeGet("rest/listProduits", "failed to list products", function(response) {	
			listProduits = response;
			if (listProduits == null) return;
            var len = listProduits.length;
            alert(len);
			for (var i=0; i < listProduits.length; i++) {
				var produit = listProduits[i];
				//var pid = produit.id;
				//var clid = client.id;
				$("#ListOfProducts").append( "<div class=p-flex><div class=p-flex-in> \n " +
						"  <img class=p-img src="+produit.url+" />" +
						"  <div class=p-name>"+produit.nom+"</div> \n" +
						"  <div class=p-price>€"+produit.prix+"</div> \n" +
                        "  <div class=p-name>"+produit.category+"</div> \n " +
						"  <div class=p-desc>"+produit.description+"</div> \n " +
						"  <button onclick=myFunction(client,produit) class=p-add>Acheter</button> \n" +
						"</div></div>");
				//afficherPopupInformation("cl : " + client.id);
			}
			
		});
		
		


	});
	
}

function myFunction(client,produit){
	
	//ass = {};
	//ass.produitId = produit.id;
	//ass.clientId = client.id;

	//afficherPopupInformation("produit ");
	listClients = invokeGet("rest/listClients", "failed to list clients", function(response) {
		listClients = response;
		if (listClients == null) return;
		for (var i=0; i < listClients.length; i++) {
		var person = listClients[i];
		if (person.username == client.username && person.password==client.password) {
			
			listpdts = invokeGet("rest/listProduits", "failed to list products", function(response) {
				listpdts = response;
				if (listpdts == null) return;
				for (var i=0; i < listpdts.length; i++) {
					var pd = listpdts[i];
					if (pd.nom == produit.nom ) {
						ass = {};
						ass.produitId = pd.id;
						ass.clientId = person.id;
						//invokePost("rest/ajoutpd", produit,client, "association was created", "failed to create association");
						invokePost("rest/ajouter", ass, "association was created", "failed to create association");
						//loadMain();
					}
					
				}
			});
		}

		
		}
	});
	
}


function loadIdentification(){
	$("#ShowMessage").empty();
	$("#Main").load("Identification.html", function() {	
		
		$("#BTConnect").click(function() {
			compteconnect = {};
			compteconnect.username=$("#nom").val();
			compteconnect.password=$("#mdp").val();
			//loadMain();
			loadverification(compteconnect);
			//invokePost("rest/addClient", client, "client was added", "failed to add a client");			
			
		});
		
		$("#BTreturn").click(function() {

			loadMain();
			
		});
		$("#BTinscription").click(function() {
			//client = {};
			//compte = {};
			loadAddClient();
			
		});

	});
}

function loadverification(compteconnect) {
	//afficherPopupInformation("Bienvenue !" + compte.username + compte.password);
	//swal("Bienvenue !", compte.username , compte.password);
	//$("#ShowMessage").empty();
	
	/*$("#Main").load("Espaceclient.html", function() {	
		
		
	});*/
	var listclients;
	invokeGet("rest/listClients", "failed to list clients", function(response) {
		listclients = response;
		var k = parseInt("0");
		if (listclients == null) {alert("liste vide aucun client n'est inscrit!") ;}

		for (var i=0; i < listclients.length; i++) {
			var client = listclients[i];
			var courant = client.compte ;
			if (courant.username === compteconnect.username) {
				k = parseInt("1");
				if (courant.password === compteconnect.password ) {
					//afficherPopupInformation("Bienvenue "+ courant.username + " " + courant.password + "\n");
					//var own = courant.owner;
					//afficherPopupInformation("Bienvenue "+ client.nom + " " + client.prenom +" \n");
					loadEspaceClient(client);
				}
				else {
					alert("Mot de passe erroné !");
				}
			}
		}
		if (k===parseInt("0")) {
			alert("Votre username est inconnue !");
		}
	});
}

function loadEspaceClient(client){
	$("#ShowMessage").empty();
	$("#Main").load("EspaceClient.html", function() {	
		
		$("#BTContact").click(function() {
			loadContact();
		});
	
		$("#BTDeconnexion").click(function() {
			loadMain();
		});
		
		$("#BTMonProfil").click(function() {
			loadMonProfil(client);
			
		});
		
		$("#BTList").click(function() {
			loadListcl(client);
		});
		
		$("#BThistory").click(function() {
			history(client)
		});

});
}

function loadAjoutProduit(){
    $("#ShowMessge").empty();
    $("#Main").load("AddProduct.html",function(){

        $("#BTConfirmer").click(function() {
            produit={};
            produit.nom=$("#name").val();
            produit.description=$("#description").val();
            produit.prix=$("#prix").val();
            produit.url=$("#url").val();
            var a = $("#categorie option:selected").text();
            produit.category=a;
            invokePost("rest/addProduct", produit, "product was added", "failed to add a product");


            var listproduits,listpdts;
         invokeGet("rest/listProduits", "failed to list products", function(response){ 
                listproduits = response;

         invokeGet("rest/listCategories", "failed to list products", function(response) {
             listpdts=response;


                var pp=listproduits[listproduits.length-1];
                if (listpdts == null) return;
                for (var i=0; i < listpdts.length; i++) {
                    var pd = listpdts[i];
                    var b = pd.name;
                    if (pp.category===pd.name) {
                        ass = {};
                        ass.produitId = pp.id;
                        ass.categorieId = pd.id;
                        //invokePost("rest/ajoutpd", produit,client, "association was created", "failed to create association");
                        invokePost("rest/associatecat", ass, "association was created", "failed to create association");
                        //loadMain();
                    }

                }
            });
            });

            loadMain();
        });

    })
}

function loadContact() {
	$("#ShowMessage").empty();
	$("#Main").load("Contact.html", function() {
	
});
}
function loadMonProfil(client) {
    $("#ShowMessage").empty();
    //if (client == null) return;
    list="<ul>";           
    list+="<li>"+"Nom "+client.nom+"</li>";
    list+="<br>";
    list+="<li>"+"Prenom "+client.prenom+"</li>";       
    $("#Main").empty();
    $("#Main").append(list);

}
   


function invokePost(url, data, successMsg, failureMsg) {
	jQuery.ajax({
	    url: url,
	    type: "POST",
	    data: JSON.stringify(data),
	    dataType: "json",
	    contentType: "application/json; charset=utf-8",
	    success: function (response) {
	    	//$("#ShowMessage").text(successMsg);
	    },
	    error: function (response) {
	    	$("#ShowMessage").text(failureMsg);
	    }
	});
}
function invokeGet(url, failureMsg, responseHandler) {
	jQuery.ajax({
	    url: url,
	    type: "GET",
	    success: responseHandler,
	    error: function (response) {
	    	$("#ShowMessage").text(failureMsg);
	    }
	});
}