package pack;

import java.io.Serializable;

public class AssociationCategorie implements Serializable {
	
	int CategorieId;
	int ProduitId;
	
	public int getCategorieId() {
		return CategorieId;
	}
	public void setCategorieId(int CategorieId) {
		this.CategorieId = CategorieId;
	}
	public int getProduitId(){
		return ProduitId;
	}
	public void setProduitId(int ProduitId) {
		this.ProduitId = ProduitId;
	}
	public AssociationCategorie(Categorie categorie, Produit produit) {
		super();
		CategorieId = categorie.getId();
		ProduitId = produit.getId();
	}
	
	public AssociationCategorie() {
		super();
	}
	
	
}