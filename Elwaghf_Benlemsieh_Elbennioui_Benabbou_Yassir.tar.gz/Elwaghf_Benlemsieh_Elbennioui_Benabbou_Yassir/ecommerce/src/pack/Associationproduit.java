package pack;

import java.io.Serializable;

public class Associationproduit implements Serializable {
	int ClientId;
	int ProduitId;
	
	public int getClientId() {
		return ClientId;
	}
	public void setClientId(int ClientId) {
		this.ClientId = ClientId;
	}
	public int getProduitId() {
		return ProduitId;
	}
	public void setProduitId(int ProduitId) {
		this.ProduitId = ProduitId;
	}
	public Associationproduit(Client client, Produit produit) {
		super();
		ClientId = client.getId();
		ProduitId = produit.getId();
	}
	
	public Associationproduit() {
		super();
	}
	
	
}