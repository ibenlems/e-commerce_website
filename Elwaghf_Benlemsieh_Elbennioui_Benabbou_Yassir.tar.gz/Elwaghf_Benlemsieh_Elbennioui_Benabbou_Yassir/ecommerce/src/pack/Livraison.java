package pack;

public class Livraison {
	int LivreurId;
	int ProduitId;
	
	
	
	public Livraison(Livreur livreur, Produit produit) {
		super();
		LivreurId = livreur.getId();
		ProduitId = produit.getId();
	}
	
	public Livraison() {
		super();
	}

	public int getLivreurId() {
		return LivreurId;
	}

	public void setLivreurId(int livreurId) {
		LivreurId = livreurId;
	}

	public int getProduitId() {
		return ProduitId;
	}

	public void setProduitId(int produitId) {
		ProduitId = produitId;
	}

}
