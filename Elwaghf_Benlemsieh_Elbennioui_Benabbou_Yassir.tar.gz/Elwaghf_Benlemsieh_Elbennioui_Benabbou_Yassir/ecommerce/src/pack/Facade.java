package pack;

import java.util.ArrayList;
import java.util.Collection;

import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@Singleton
@Path("/")
public class Facade {

	@PersistenceContext
	EntityManager em;
	
	@POST
	@Path("/addClient")
    @Consumes({ "application/json" })
	public void addClient(Client p) {
		System.out.println("coucou");
		em.persist(p);
	}
	
	@POST
	@Path("/addCompte")
    @Consumes({ "application/json" })
	public void addCompte(Compte a) {
		em.persist(a);
	}
	
	
	@GET
	@Path("/listClients")
    @Produces({ "application/json" })
	public Collection<Client> listClients() {
		return em.createQuery("from Client", Client.class).getResultList();
	}
	
	@GET
	@Path("/listComptes")
    @Produces({ "application/json" })
	public Collection<Compte> listComptes() {
		return em.createQuery("from Compte", Compte.class).getResultList();	
	}
	
	@POST
	@Path("/associate")
    @Consumes({ "application/json" })
	public void associate(Association as) {
		Client client = em.find(Client.class, as.getClientId());
		Compte compte = em.find(Compte.class, as.getCompteId());		
		compte.setOwner(client);
	}
	
	@POST
	@Path("/ajouter")
    @Consumes({ "application/json" })
	public void ajouterproduit(Associationproduit as) {
		Client client = em.find(Client.class, as.getClientId());
		Produit produit = em.find(Produit.class, as.getProduitId());
		Collection<Client> newc = produit.getAcheteurs();
		newc.add(client);
		produit.setAcheteurs(newc);
	}
	
	@POST
	@Path("/livrer")
    @Consumes({ "application/json" })
	public void livrer(Livraison as) {
		Livreur livreur = em.find(Livreur.class, as.getLivreurId());
		Produit produit = em.find(Produit.class, as.getProduitId());
		produit.setLivreur(livreur);
	}
	
	@GET
	@Path("/listProduits")
    @Produces({ "application/json" })
	public Collection<Produit> listProduits() {
		return em.createQuery("from Produit", Produit.class).getResultList();	
	}
	
	@GET
	@Path("/listLivreurs")
    @Produces({ "application/json" })
	public Collection<Livreur> listLivreurs() {
		return em.createQuery("from Livreur", Livreur.class).getResultList();	
	}
	
	@POST
    @Path("/addProduct")
    @Consumes({ "application/json" })
    public void addProduct(Produit p) {
        em.persist(p);
    }
	
	@POST
	@Path("/addLivreur")
    @Consumes({ "application/json" })
	public void addLivreur(Livreur l) {
		em.persist(l);
	}
	
	
	@POST
    @Path("/addCategorie")
    @Consumes({ "application/json" })
    public void addCategorie(Categorie c) {
        em.persist(c);
    }


    @POST
    @Path("/associatecat")
    @Consumes({ "application/json" })
    public void associate(AssociationCategorie as) {
        Categorie cat = em.find(Categorie.class, as.getCategorieId());
        Produit produit = em.find(Produit.class, as.getProduitId());
        cat.getProduits().add(produit);
        produit.setCategorie(cat);
    }
    @GET
    @Path("/listCategories")
    @Produces({ "application/json" })
    public Collection<Categorie> listCategories() {
        return em.createQuery("from Categorie", Categorie.class).getResultList();
    }
}
