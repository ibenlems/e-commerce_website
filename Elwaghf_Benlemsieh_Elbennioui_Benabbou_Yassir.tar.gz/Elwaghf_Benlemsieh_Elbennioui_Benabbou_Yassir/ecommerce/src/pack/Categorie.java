package pack;


import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;




@Entity
public class Categorie {

	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	int id;
	
	String name;
	
	@OneToMany(mappedBy="categorie",fetch=FetchType.EAGER)
	Collection<Produit> produits = new ArrayList<Produit>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Collection<Produit> getProduits() {
		return produits;
	}

	public void setProduits(Collection<Produit> produits) {
		this.produits = produits;
	}

	
	
	
	

	
	

}