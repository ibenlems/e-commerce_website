/**
 * 
 */

$(document).ready(function() {
	loadMain();
});

function loadMain() {
	$("#Main").load("Main.html", function() {
		client = {};
		compte = {};
		$("#BTInscription").click(function() {
				loadAddClient(client,compte);
						
		});
			
		$("#BTList").click(function() {
			loadList();
		});
	});
}

function loadAddClient(client,compte){
	$("#ShowMessage").empty();
	$("#Main").load("AddInscription.html", function() {	
		
		
		$("#BTVSuivant").click(function() {
					
			client.nom=$("#nom").val();
			client.prenom=$("#prenom").val();	
			
			invokePost("rest/addClient", client, "client was added", "failed to add a client");
			loadAddCompte(compte);
			
			
		});

	});
}


function confirmer(mdp,cmdp){
	if($mdp.val() != $mdp.val()){ // si la confirmation est différente du mot de passe
        $(this).css({ // on rend le champ rouge
 	        borderColor : 'red',
    	color : 'red'
        });
    }
    else{
	    $(this).css({ // si tout est bon, on le rend vert
	        borderColor : 'green',
	        color : 'green'
	    });
    }
}
   


function loadAddCompte(compte) {

	$("#Main").load("AddCompte.html", function() {
		
		var $champ = $('.champ');
	
	
		// le code précédent se trouve ici
	
		$champ.keyup(function(){
			
		    if($(this).val().length < 8){ // si la chaîne de caractères est inférieure à 5
		        $(this).css({ // on rend le champ rouge
		            borderColor : 'red',
			    color : 'red'
		        });
		     }
		     else{
		         $(this).css({ // si tout est bon, on le rend vert
			     borderColor : 'green',
			     color : 'green'
			 });
		     }
		});
	
	
		$("#BTVCompte").click(function() {				
			
				compte.username=$("#username").val();
				compte.password=$("#password").val();
				
				invokePost("rest/addCompte", compte, "compte was added", "failed to add a compte");
				loadAddCompte(compte);
			
			
		});
		$("#BTVFinir").click(function() {
			loadAddAssociation(client,compte);
		});
		
	});
}


function loadAddAssociation(client,compte) {

	invokePost("rest/associate", client, compte, "association was added", "failed to add an association");
	loadMain();
}


function invokePost(url, data, successMsg, failureMsg) {
	jQuery.ajax({
	    url: url,
	    type: "POST",
	    data: JSON.stringify(data),
	    dataType: "json",
	    contentType: "application/json; charset=utf-8",
	    success: function (response) {
	    	$("#ShowMessage").text(successMsg);
	    },
	    error: function (response) {
	    	$("#ShowMessage").text(failureMsg);
	    }
	});
}
function invokeGet(url, failureMsg, responseHandler) {
	jQuery.ajax({
	    url: url,
	    type: "GET",
	    success: responseHandler,
	    error: function (response) {
	    	$("#ShowMessage").text(failureMsg);
	    }
	});
}







/*
function loadInscription() {
$("#ShowMessage").empty();
$("#Main").load("AddInscription.html", function() {
	$("#BTVInscription").click(function() {
		client = {};
		client.nom=$("#nom").val();
		client.prenom=$("#prenom").val();		

		invokePost("rest/addClient", client, "client was added", "failed to add a client");
		
		compte = {};
		compte.username=$("#username").val();
		compte.password=$("#password").val();		
		
		
		ass = {};
		ass.clientId= invokeGet("rest/idClient", client,"failed to id client", function(response) {
			ass.clientId= response;});				
		ass.compteId=invokeGet("rest/idCompte",compte, "failed to id compte", function(response) {
			ass.compteId= response;});
		
		
		invokePost("rest/addCompte", compte, "compte was added", "failed to add a compte");
		invokePost("rest/associate", ass, "association was created", "failed to create association");
	
	});
	$("#BTVMain").click(function() {
		loadMain();
	});
});
}

*/