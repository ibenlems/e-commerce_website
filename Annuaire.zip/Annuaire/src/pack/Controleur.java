
package pack;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Controleur
 */
@WebServlet("/Controleur")
public class Controleur extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controleur() {
        super();
        // TODO Auto-generated constructor stub
    }
   
    @EJB
    private Facade f;
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String op = request.getParameter("op");
		switch(op) {
		
		case "ajoutPersonne" :
			f.ajoutPersonne(request.getParameter("nom"), request.getParameter("prenom"));
			request.getRequestDispatcher("index.html").forward(request, response);
			return;
			
		case "ajoutAdresse":
			
			f.ajoutAdresse(request.getParameter("rue"), request.getParameter("ville"));
			request.getRequestDispatcher("index.html").forward(request, response);
			return;
					
		case "associer" :
			request.setAttribute("lp",f.listePersonnes());
			request.setAttribute("la", f.listeAdresses());
			request.getRequestDispatcher("associer.jsp").forward(request,response);
			return;
			
		case "lister" :
		
			request.setAttribute("lp",f.listePersonnes());
			request.setAttribute("la", f.listeAdresses());
			request.getRequestDispatcher("lister.jsp").forward(request,response);
			return;
			
		case "vassocier":
			
			
			int idp = Integer.parseInt(request.getParameter("idp"));
			int ida = Integer.parseInt(request.getParameter("ida"));
			f.associer(idp, ida);
			request.getRequestDispatcher("index.html").forward(request, response);
			return;
			
			
			
			
			
			
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		doGet(request, response);
	}

}
