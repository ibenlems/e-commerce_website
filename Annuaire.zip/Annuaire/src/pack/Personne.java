package pack;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.*;

@Entity
public class Personne {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int id;
	String nom;
	String prenom;

	@OneToMany
	Collection<Adresse> Adresses;
	
	
	public Personne(String nom,String prenom,int id) {
		this.nom=nom;
		this.prenom=prenom;
		this.id =id;
		
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public String getPrenom() {
		return prenom;
	}


	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}


	public Collection<Adresse> getAdresses() {
		return Adresses;
	}


	public void setAdresses(Collection<Adresse> adresses) {
		Adresses = adresses;
	}

	
	//public void AjouterAdressse(Adresse d) {
		//this.Adresses.add(d);
	//}

}
