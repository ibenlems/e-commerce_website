package pack;

import java.util.Collection;
import org.hsqldb.jdbcDriver;
import java.util.HashMap;
import java.sql.*;

import javax.ejb.Singleton;
import javax.persistence.*;

@Singleton
public class Facade {
	
	int ComptPersonne=0;
	
	int ComptAdresse=0;
	
	@PersistenceContext
	private EntityManager em;
	
		
	public void ajoutPersonne(String nom, String prenom)  {
		
		Personne p = new Personne(nom,prenom,ComptPersonne+1);
		em.persist(p);
		ComptPersonne += 1;
				
	}
	
	public void ajoutAdresse(String rue, String ville)  {
		
		Adresse d = new Adresse(rue,ville,ComptAdresse+1);
		em.persist(d);
		ComptAdresse += 1;
	}
	
	public Collection<Personne> listePersonnes() {

		TypedQuery<Personne> req = em.createQuery("select p from Personne p",Personne.class);
		return req.getResultList();
	}
	
	public Collection<Adresse> listeAdresses(){
		TypedQuery<Adresse> req = em.createQuery("select a from Adresse a",Adresse.class);
		return req.getResultList();
	}

	public void associer(int personneId, int adresseId) {
		Personne p = em.find(Personne.class, personneId);
		Adresse d = em.find(Adresse.class, adresseId);
		em.persist(d);
		p.getAdresses().add(d);
	}
}
