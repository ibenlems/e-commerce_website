/**
 * 
 */

$(document).ready(function() {
	loadMain();
});

function loadMain() {
	$("#Main").load("Main.html", function() {

		$("#BTInscription").click(function() {
				loadAddClient();
						
		});
		
		$("#BTIdentification").click(function() {
			loadIdentification();
					
		});
		
		$("#BTAjoutProduit").click(function() {
			loadAjoutProduit();
		});
		
		$("#BTList").click(function() {
			loadList();
		});
	});
}

function loadAddClient(){
	$("#ShowMessage").empty();
	$("#Main").load("AddClient.html", function() {		
		
		$("#BTVSuivant").click(function() {
			client = {};
			client.nom=$("#nom").val();
			client.prenom=$("#prenom").val();				
			invokePost("rest/addClient", client, "client was added", "failed to add a client");			
			loadAddCompte();
			
			
		});

	});
}


function loadAddCompte() {

	$("#Main").load("AddCompte.html", function() {
		
		var $champ = $('.champ');	
	
		// le code précédent se trouve ici
	
		$champ.keyup(function(){
			
		    if($(this).val().length < 8){ // si la chaîne de caractères est inférieure à 5
		        $(this).css({ // on rend le champ rouge
		            borderColor : 'red',
			    color : 'red'
		        });
		     }
		     else{
		         $(this).css({ // si tout est bon, on le rend vert
			     borderColor : 'green',
			     color : 'green'
			 });
		     }
		});
	
	
		$("#BTVValider").click(function() {				

			    compte = {};
				compte.username=$("#username").val();
				compte.password=$("#password").val();
						
				
				invokePost("rest/addCompte", compte, "compte was added", "failed to add a compte");
				
				var listClients, listComptes;
				invokeGet("rest/listClients", "failed to list comptes", function(response) {
					listClients = response;
					if (listClients == null) return;
					listComptes = invokeGet("rest/listComptes", "failed to list clients", function(response) {
						listComptes = response;
						if (listComptes == null) return;
						var person = listClients[listClients.length - 1];
						var comptep = listComptes[listComptes.length - 1];
						ass = {};
						ass.clientId = person.id;
						ass.compteId = comptep.id;
						invokePost("rest/associate", ass, "association was created", "failed to create association");
						loadMain();
					});
				});	
			
			
		});
		
	});
}

function loadList(){
	$("#ShowMessage").empty();
	$("#Main").load("ListProduits.html", function() {
		/*invokeGet("rest/listProduits", "failed to list products", function(response) {			
		});*/
		
		for (var i=0;i<8;i++){
		$("#ListOfProducts").append( "<div class=p-flex><div class=p-flex-in> \n " +
				"  <img  class=p-img src=images/shopping.png />" +
				"  <div class=p-name>nom du prdouit</div> \n" +
				"  <div class=p-price>€prix</div> \n" +
				"  <div class=p-desc>description</div> \n " +
				"  <button class=p-add>Acheter</button> \n" +
				"</div></div>");
		}
		
		invokeGet("rest/listProduits", "failed to list products", function(response) {	
			
			listProduits = response;
			if (listProduits == null) return;
			for (var i=0; i < listProduits.length; i++) {
				var produit = listProduits[i];					
				$("#ListOfProducts").append( "<div class=p-flex><div class=p-flex-in> \n " +
						"  <img class=p-img src="+produit.url+" />" +
						"  <div class=p-name>"+produit.nom+"</div> \n" +
						"  <div class=p-price>€"+produit.prix+"</div> \n" +
						"  <div class=p-desc>"+produit.description+"</div> \n " +
						"  <button onclick=myFunction(produit) class=p-add>Acheter</button> \n" +
						"</div></div>");
			}
			/*function displayProduct(id) {
				System.out.println("wajia");
				}*/
			
		});
		
		


	});
	
}

function loadListcl(client){
	$("#ShowMessage").empty();
	$("#Main").load("ListProduits.html", function() {
		/*invokeGet("rest/listProduits", "failed to list products", function(response) {			
		});*/
		
		for (var i=0;i<8;i++){
		$("#ListOfProducts").append( "<div class=p-flex><div class=p-flex-in> \n " +
				"  <img  class=p-img src=images/shopping.png />" +
				"  <div class=p-name>nom du prdouit</div> \n" +
				"  <div class=p-price>€prix</div> \n" +
				"  <div class=p-desc>description</div> \n " +
				"  <button class=p-add>Acheter</button> \n" +
				"</div></div>");
		}
		
		invokeGet("rest/listProduits", "failed to list products", function(response) {	
			
			listProduits = response;
			if (listProduits == null) return;
			for (var i=0; i < listProduits.length; i++) {
				var produit = listProduits[i];
				//var pid = produit.id;
				//var clid = client.id;
				$("#ListOfProducts").append( "<div class=p-flex><div class=p-flex-in> \n " +
						"  <img class=p-img src="+produit.url+" />" +
						"  <div class=p-name>"+produit.nom+"</div> \n" +
						"  <div class=p-price>€"+produit.prix+"</div> \n" +
						"  <div class=p-desc>"+produit.description+"</div> \n " +
						"  <button onclick=myFunction(client,produit) class=p-add>Acheter</button> \n" +
						"</div></div>");
				//afficherPopupInformation("cl : " + client.id);
			}
			
		});
		
		


	});
	
}

function myFunction(client,produit){
	
	//ass = {};
	//ass.produitId = produit.id;
	//ass.clientId = client.id;
	afficherPopupInformation("produitid : ");
	/*invokePost("rest/ajoutpd", produit,client, "association was created", "failed to create association");
	//afficherPopupInformation("produit ");
	listClients = invokeGet("rest/listClients", "failed to list clients", function(response) {
		listClients = response;
		if (listClients == null) return;
		for (var i=0; i < listClients.length; i++) {
		var person = listClients[i];
		if (person.username == client.username && person.password==client.password) {
			
			listpdts = invokeGet("rest/listProduits", "failed to list products", function(response) {
				listpdts = response;
				if (listpdts == null) return;
				for (var i=0; i < listpdts.length; i++) {
					var pd = listpdts[i];
					if (pd.nom == produit.nom ) {
						ass = {};
						ass.produitId = pd.id;
						ass.clientId = person.id;
						//invokePost("rest/ajoutpd", produit,client, "association was created", "failed to create association");
						invokePost("rest/ajouter", ass, "association was created", "failed to create association");
						//loadMain();
					}
					
				}
			});
		}

		
		}
	});
	*/
}


function loadIdentification(){
	$("#ShowMessage").empty();
	$("#Main").load("Identification.html", function() {	
		
		$("#BTConnect").click(function() {
			compteconnect = {};
			compteconnect.username=$("#nom").val();
			compteconnect.password=$("#mdp").val();
			//loadMain();
			loadverification(compteconnect);
			//invokePost("rest/addClient", client, "client was added", "failed to add a client");			
			
		});
		
		$("#BTreturn").click(function() {

			loadMain();
			
		});
		$("#BTinscription").click(function() {
			//client = {};
			//compte = {};
			loadAddClient();
			
		});

	});
}

function loadverification(compteconnect) {
	//afficherPopupInformation("Bienvenue !" + compte.username + compte.password);
	//swal("Bienvenue !", compte.username , compte.password);
	//$("#ShowMessage").empty();
	
	/*$("#Main").load("Espaceclient.html", function() {	
		
		
	});*/
	var listclients;
	invokeGet("rest/listClients", "failed to list clients", function(response) {
		listclients = response;
		if (listclients == null) {afficherPopupInformation("liste vide aucun client n'est inscrit!") ;}

		for (var i=0; i < listclients.length; i++) {
			var client = listclients[i];
			var courant = client.compte ;
			if (courant.username === compteconnect.username) {
				if (courant.password === compteconnect.password ) {
					//afficherPopupInformation("Bienvenue "+ courant.username + " " + courant.password + "\n");
					//var own = courant.owner;
					//afficherPopupInformation("Bienvenue "+ client.nom + " " + client.prenom +" \n");
					loadEspaceClient(client);
				} 
			}
			
		}
	});
}

function loadEspaceClient(client){
	$("#ShowMessage").empty();
	$("#Main").load("EspaceClient.html", function() {	
		
		$("#BTContact").click(function() {
			loadContact();
		});
	
		$("#BTDeconnexion").click(function() {
			loadMain();
		});
		
		$("#BTMonProfil").click(function() {
			loadMonProfil(client);
			
		});
		
		$("#BTList").click(function() {
			loadListcl(client);
		});

});
}

function loadAjoutProduit(){
	$("#ShowMessge").empty();
	$("#Main").load("AddProduct.html",function(){

		$("#BTConfirmer").click(function() {
		    produit={};	
			produit.nom=$("#name").val();
			produit.description=$("#description").val();
			produit.prix=$("#prix").val();	
			produit.url=$("#url").val();
	
			invokePost("rest/addProduct", produit, "product was added", "failed to add a product");
			loadMain();			
		});
		
	})
}

function loadContact() {
	$("#ShowMessage").empty();
	$("#Main").load("Contact.html", function() {
	
});
}
function loadMonProfil(client) {
    $("#ShowMessage").empty();
    //if (client == null) return;
    list="<ul>";           
    list+="<li>"+"Nom "+client.nom+"</li>";
    list+="<br>";
    list+="<li>"+"Prenom "+client.prenom+"</li>";       
    $("#Main").empty();
    $("#Main").append(list);

}
   






//Affiche un popup d'information et l'usager doit cliquer sur OK pour le refermer

//source : http://christianelagace.com

//Paramètre : le texte du message qui sera affiché dans le popup

//Retourne une référence à la boîte de dialogue



function afficherPopupInformation(message) {

 // crée la division qui sera convertie en popup

 $('body').append('<div id="popupinformation" title="Information"></div>');

 $("#popupinformation").html(message);



 // transforme la division en popup

 var popup = $("#popupinformation").dialog({

     autoOpen: true,

     width: 400,

     dialogClass: 'dialogstyleperso',

     buttons: [

         {

             text: "OK",

             "class": 'ui-state-information',

             click: function () {

                 $(this).dialog("close");

                 $('#popupinformation').remove();

             }

         }

     ]

 });



 // ajouter le style à la barre de titre

 // note : on n'utilise pas .dialogClass dans la définition de la boîte de dialogue car mettrait tout le fond en couleur

 $("#popupinformation").prev().addClass('ui-state-information');



 return popup;

}


function invokePost(url, data, successMsg, failureMsg) {
	jQuery.ajax({
	    url: url,
	    type: "POST",
	    data: JSON.stringify(data),
	    dataType: "json",
	    contentType: "application/json; charset=utf-8",
	    success: function (response) {
	    	$("#ShowMessage").text(successMsg);
	    },
	    error: function (response) {
	    	$("#ShowMessage").text(failureMsg);
	    }
	});
}
function invokeGet(url, failureMsg, responseHandler) {
	jQuery.ajax({
	    url: url,
	    type: "GET",
	    success: responseHandler,
	    error: function (response) {
	    	$("#ShowMessage").text(failureMsg);
	    }
	});
}