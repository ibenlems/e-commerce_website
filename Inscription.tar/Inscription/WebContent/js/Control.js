/**
 * 
 */

$(document).ready(function() {
	loadMain();
});

function loadMain() {
	$("#Main").load("Main.html", function() {
		//client = {};
		//compte = {};
		$("#BTInscription").click(function() {
				loadAddClient();
						
		});
		
		$("#BTIdentification").click(function() {
			loadIdentification();
					
		});
		
		$("#BTList").click(function() {
			loadList();
		});
	});
}

function loadAddClient(){
	$("#ShowMessage").empty();
	$("#Main").load("AddInscription.html", function() {		
		
		
		$("#BTVSuivant").click(function() {
			
			client = {};
			client.nom=$("#nom").val();
			client.prenom=$("#prenom").val();				
			invokePost("rest/addClient", client, "client was added", "failed to add a client");
			
			loadAddCompte(client);
			
			
		});

	});
}

function loadList(){
	$("#ShowMessage").empty();
	$("#Main").load("ListProduits.html", function() {
		/*invokeGet("rest/listProduits", "failed to list products", function(response) {			
		});*/
		
		for (var i=0;i<8;i++){
		$("#ListOfProducts").append( "<div class=p-flex><div class=p-flex-in> \n " +
				"  <img  class=p-img src=images/shopping.png />" +
				"  <div class=p-name>nom du prdouit</div> \n" +
				"  <div class=p-price>€prix</div> \n" +
				"  <div class=p-desc>description</div> \n " +
				"  <button class=p-add>Acheter</button> \n" +
				"</div></div>");
		}
		/*$("#flex").append("<div class=p-flex><div class=p-flex-in>");	
		$("#flex").append("  "+"<img class=p-img src=images/pic01.jpg/>");
		$("#flex").append("  "+"<div class=p-name>nom du prdouit</div>");
		$("#flex").append("  "+"<div class=p-price>€prix</div>");
		$("#flex").append("  "+"<div class=p-desc>description</div>");
		$("#flex").append("  "+"<button class=p-add>Acheter</button>");
		$("#flex").append("</div></div>");*/

	});
	
}


function loadIdentification(){
	$("#ShowMessage").empty();
	$("#Main").load("Identification.html", function() {	
		
		$("#BTConnect").click(function() {
			compteconnect = {};
			compteconnect.username=$("#nom").val();
			compteconnect.password=$("#mdp").val();
			//loadMain();
			loadverification(compteconnect);
			//invokePost("rest/addClient", client, "client was added", "failed to add a client");			
			
		});
		
		$("#BTreturn").click(function() {

			loadMain();
			
		});
		$("#BTinscription").click(function() {
			//client = {};
			//compte = {};
			loadAddClient();
			
		});

	});
}

function loadverification(compteconnect) {
	//afficherPopupInformation("Bienvenue !" + compte.username + compte.password);
	//swal("Bienvenue !", compte.username , compte.password);
	//$("#ShowMessage").empty();
	
	/*$("#Main").load("Espaceclient.html", function() {	
		
		
	});*/
	var listclients;
	invokeGet("rest/listClients", "failed to list clients", function(response) {
		listclients = response;
		if (listclients == null) {afficherPopupInformation("liste vide aucun client n'est inscrit!") ;}

		for (var i=0; i < listclients.length; i++) {
			var client = listclients[i];
			var courant = client.compte ;
			//afficherPopupInformation("Bienvenue !"+ courant.owner.nom + courant.owner.prenom );
			//afficherPopupInformation("Bienvenue !"+ courant.username + courant.password );
			//afficherPopupInformation("Bienvenue !"+ courant.username + courant.password );
			//afficherPopupInformation("Bienvenue "+ client.nom + " " + client.prenom +" \n");
			if (courant.username === compteconnect.username) {
				if (courant.password === compteconnect.password ) {
					//afficherPopupInformation("Bienvenue "+ courant.username + " " + courant.password + "\n");
					//var own = courant.owner;
					afficherPopupInformation("Bienvenue "+ client.nom + " " + client.prenom +" \n");
				} else {
			        $(this).css({ // on rend le champ rouge
			 	        borderColor : 'red',
			    	color : 'red'
			        });
				}
			}
			else {
		        $(this).css({ // on rend le champ rouge
		 	        borderColor : 'red',
		    	color : 'red'
		        });
			}
		}
	});
}

function confirmer(mdp,cmdp){
	if($mdp.val() != $mdp.val()){ // si la confirmation est différente du mot de passe
        $(this).css({ // on rend le champ rouge
 	        borderColor : 'red',
    	color : 'red'
        });
    }
    else{
	    $(this).css({ // si tout est bon, on le rend vert
	        borderColor : 'green',
	        color : 'green'
	    });
    }
}
   



function loadAddCompte(client) {

	$("#Main").load("AddCompte.html", function() {
		
		var $champ = $('.champ');	
	
		// le code précédent se trouve ici
	
		$champ.keyup(function(){
			
		    if($(this).val().length < 8){ // si la chaîne de caractères est inférieure à 5
		        $(this).css({ // on rend le champ rouge
		            borderColor : 'red',
			    color : 'red'
		        });
		     }
		     else{
		         $(this).css({ // si tout est bon, on le rend vert
			     borderColor : 'green',
			     color : 'green'
			 });
		     }
		});
	
	
		$("#BTVCompte").click(function() {				

			    compte = {};
				compte.username=$("#username").val();
				compte.password=$("#password").val();
						
				
				invokePost("rest/addCompte", compte, "compte was added", "failed to add a compte");
				//loadAddAssociation(client,compte);

				var listClients, listComptes;
				invokeGet("rest/listClients", "failed to list comptes", function(response) {
					listClients = response;
					if (listClients == null) return;
					listComptes = invokeGet("rest/listComptes", "failed to list clients", function(response) {
						listComptes = response;
						if (listComptes == null) return;
						var person = listClients[listClients.length - 1];
						var comptep = listComptes[listComptes.length - 1];
						ass = {};
						ass.clientId = person.id;
						ass.compteId = comptep.id;
						invokePost("rest/associate", ass, "association was created", "failed to create association");
						loadMain();
					});
				});
				//var dataId = $(compte).attr("id");
				//afficherPopupInformation(dataId);
				
				

				
				
				//loadCompte(client,compte);
				//invokePost("rest/associate", client, compte, "association was added", "failed to add an association");
				//loadMain();
				//("rest/associate", ass, "association was created", "failed to create association");
				//loadMain();
			
			
		});
		$("#BTVFinir").click(function() {
		    //compte = {};
			//compte.username=$("#username").val();
			//compte.password=$("#password").val();
			//loadAddAssociation(client,compte);
			loadMain();
		});
		
	});
}


function loadAddAssociation(client,compte) {
	ass = {};
	ass.clientId =1;//client.id;
	ass.compteId =2;//compte.id;
	
	//var dataId = $(compte).attr("id");
	//afficherPopupInformation(dataId);
	
	invokePost("rest/associate", ass, "association was created", "failed to create association");
	loadMain();
}


//Affiche un popup d'information et l'usager doit cliquer sur OK pour le refermer

//source : http://christianelagace.com

//Paramètre : le texte du message qui sera affiché dans le popup

//Retourne une référence à la boîte de dialogue



function afficherPopupInformation(message) {

 // crée la division qui sera convertie en popup

 $('body').append('<div id="popupinformation" title="Information"></div>');

 $("#popupinformation").html(message);



 // transforme la division en popup

 var popup = $("#popupinformation").dialog({

     autoOpen: true,

     width: 400,

     dialogClass: 'dialogstyleperso',

     buttons: [

         {

             text: "OK",

             "class": 'ui-state-information',

             click: function () {

                 $(this).dialog("close");

                 $('#popupinformation').remove();

             }

         }

     ]

 });



 // ajouter le style à la barre de titre

 // note : on n'utilise pas .dialogClass dans la définition de la boîte de dialogue car mettrait tout le fond en couleur

 $("#popupinformation").prev().addClass('ui-state-information');



 return popup;

}


function invokePost(url, data, successMsg, failureMsg) {
	jQuery.ajax({
	    url: url,
	    type: "POST",
	    data: JSON.stringify(data),
	    dataType: "json",
	    contentType: "application/json; charset=utf-8",
	    success: function (response) {
	    	$("#ShowMessage").text(successMsg);
	    },
	    error: function (response) {
	    	$("#ShowMessage").text(failureMsg);
	    }
	});
}
function invokeGet(url, failureMsg, responseHandler) {
	jQuery.ajax({
	    url: url,
	    type: "GET",
	    success: responseHandler,
	    error: function (response) {
	    	$("#ShowMessage").text(failureMsg);
	    }
	});
}







/*
function loadInscription() {
$("#ShowMessage").empty();
$("#Main").load("AddInscription.html", function() {
	$("#BTVInscription").click(function() {
		client = {};
		client.nom=$("#nom").val();
		client.prenom=$("#prenom").val();		

		invokePost("rest/addClient", client, "client was added", "failed to add a client");
		
		compte = {};
		compte.username=$("#username").val();
		compte.password=$("#password").val();		
		
		
		ass = {};
		ass.clientId= invokeGet("rest/idClient", client,"failed to id client", function(response) {
			ass.clientId= response;});				
		ass.compteId=invokeGet("rest/idCompte",compte, "failed to id compte", function(response) {
			ass.compteId= response;});
		
		
		invokePost("rest/addCompte", compte, "compte was added", "failed to add a compte");
		invokePost("rest/associate", ass, "association was created", "failed to create association");
	
	});
	$("#BTVMain").click(function() {
		loadMain();
	});
});
}

*/