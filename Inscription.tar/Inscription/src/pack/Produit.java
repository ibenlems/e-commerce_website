package pack;



import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
public class Produit {
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	int id;
	
	String nom;
	String description;
	//String ImagUrl;
	String prix;
	String url;
	
	
	@ManyToOne
	@JsonIgnore
	Client acheteur;
	
	public Client getAcheteur() {
		return acheteur;
	}
	public void setAcheteur(Client acheteur) {
		this.acheteur = acheteur;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPrix() {
		return prix;
	}
	public void setPrix(String prix) {
		this.prix = prix;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
  
	
	
}
