/**
 * 
 */

$(document).ready(function() {
	loadMain();
});

function loadMain() {
	$("#Main").load("Main.html", function() {
		client = {};
		compte = {};
		$("#BTInscription").click(function() {
				loadAddClient(client,compte);
						
		});
		
		$("#BTIdentification").click(function() {
			loadIdentification(compte);
					
		});
		
		$("#BTList").click(function() {
			loadList();
		});
	});
}

function loadAddClient(client,compte){
	$("#ShowMessage").empty();
	$("#Main").load("AddInscription.html", function() {	
		
		
		$("#BTVSuivant").click(function() {
					
			client.nom=$("#nom").val();
			client.prenom=$("#prenom").val();	
			
			invokePost("rest/addClient", client, "client was added", "failed to add a client");
			loadAddCompte(compte);
			
			
		});

	});
}

function loadIdentification(compte){
	$("#ShowMessage").empty();
	$("#Main").load("Identification.html", function() {	
		
		$("#BTConnect").click(function() {
					
			compte.username=$("#nom").val();
			compte.password=$("#mdp").val();
			//loadMain();
			loadverification(compte);
			//invokePost("rest/addClient", client, "client was added", "failed to add a client");			
			
		});
		
		$("#BTreturn").click(function() {

			loadMain();
			
		});
		$("#BTinscription").click(function() {
			client = {};
			compte = {};
			loadAddClient(client,compte);
			
		});

	});
}

function loadverification(compte) {
	$("#ShowMessage").empty();
	listcomptes = invokeGet("rest/listComptes", "failed to list comptes", function(response) {
		listcomptes = response;
		if (listcomptes == null) return;

		for (var i=0; i < listcomptes.length; i++) {
			var courant = listcomptes[i];
			if (courant.username === compte.username) {
				if (courant.password === compte.password ) {
					swal("Bienvenue !", courant.owner.nom , courant.owner.prenom);
				} else {
			        $(this).css({ // on rend le champ rouge
			 	        borderColor : 'red',
			    	color : 'red'
			        });
				}
			}
			else {
		        $(this).css({ // on rend le champ rouge
		 	        borderColor : 'red',
		    	color : 'red'
		        });
			}
		}
	});
}

function confirmer(mdp,cmdp){
	if($mdp.val() != $mdp.val()){ // si la confirmation est différente du mot de passe
        $(this).css({ // on rend le champ rouge
 	        borderColor : 'red',
    	color : 'red'
        });
    }
    else{
	    $(this).css({ // si tout est bon, on le rend vert
	        borderColor : 'green',
	        color : 'green'
	    });
    }
}
   


function loadAddCompte(compte) {

	$("#Main").load("AddCompte.html", function() {
		
		var $champ = $('.champ');
	
	
		// le code précédent se trouve ici
	
		$champ.keyup(function(){
			
		    if($(this).val().length < 8){ // si la chaîne de caractères est inférieure à 5
		        $(this).css({ // on rend le champ rouge
		            borderColor : 'red',
			    color : 'red'
		        });
		     }
		     else{
		         $(this).css({ // si tout est bon, on le rend vert
			     borderColor : 'green',
			     color : 'green'
			 });
		     }
		});
	
	
		$("#BTVCompte").click(function() {				
			
				compte.username=$("#username").val();
				compte.password=$("#password").val();
				
				invokePost("rest/addCompte", compte, "compte was added", "failed to add a compte");
				loadAddCompte(compte);
			
			
		});
		$("#BTVFinir").click(function() {
			loadAddAssociation(client,compte);
		});
		
	});
}


function loadAddAssociation(client,compte) {

	invokePost("rest/associate", client, compte, "association was added", "failed to add an association");
	loadMain();
}


function invokePost(url, data, successMsg, failureMsg) {
	jQuery.ajax({
	    url: url,
	    type: "POST",
	    data: JSON.stringify(data),
	    dataType: "json",
	    contentType: "application/json; charset=utf-8",
	    success: function (response) {
	    	$("#ShowMessage").text(successMsg);
	    },
	    error: function (response) {
	    	$("#ShowMessage").text(failureMsg);
	    }
	});
}
function invokeGet(url, failureMsg, responseHandler) {
	jQuery.ajax({
	    url: url,
	    type: "GET",
	    success: responseHandler,
	    error: function (response) {
	    	$("#ShowMessage").text(failureMsg);
	    }
	});
}







/*
function loadInscription() {
$("#ShowMessage").empty();
$("#Main").load("AddInscription.html", function() {
	$("#BTVInscription").click(function() {
		client = {};
		client.nom=$("#nom").val();
		client.prenom=$("#prenom").val();		

		invokePost("rest/addClient", client, "client was added", "failed to add a client");
		
		compte = {};
		compte.username=$("#username").val();
		compte.password=$("#password").val();		
		
		
		ass = {};
		ass.clientId= invokeGet("rest/idClient", client,"failed to id client", function(response) {
			ass.clientId= response;});				
		ass.compteId=invokeGet("rest/idCompte",compte, "failed to id compte", function(response) {
			ass.compteId= response;});
		
		
		invokePost("rest/addCompte", compte, "compte was added", "failed to add a compte");
		invokePost("rest/associate", ass, "association was created", "failed to create association");
	
	});
	$("#BTVMain").click(function() {
		loadMain();
	});
});
}

*/